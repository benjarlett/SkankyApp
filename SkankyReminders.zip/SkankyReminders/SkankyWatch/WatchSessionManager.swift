
import Foundation
import WatchConnectivity

class WatchSessionManager: NSObject, ObservableObject, WCSessionDelegate {
    @Published var loops: [Loop] = []
    @Published var setlists: [Setlist] = []
    @Published var bands: [Band] = []
    @Published var playingLoopID: UUID? = nil

    override init() {
        super.init()
        if WCSession.isSupported() {
            let session = WCSession.default
            session.delegate = self
            session.activate()
        }
    }

    // MARK: - Command Sending

    func playLoop(loopID: UUID) {
        guard WCSession.default.isReachable else {
            print("Watch: iPhone is not reachable.")
            return
        }
        let message = ["command": "play", "loopID": loopID.uuidString]
        WCSession.default.sendMessage(message, replyHandler: nil) { error in
            print("Watch error sending play command: \(error.localizedDescription)")
        }
    }

    func stopLoop() {
        guard WCSession.default.isReachable else {
            print("Watch: iPhone is not reachable.")
            return
        }
        let message = ["command": "stop"]
        WCSession.default.sendMessage(message, replyHandler: nil) { error in
            print("Watch error sending stop command: \(error.localizedDescription)")
        }
    }

    func requestSync() {
        guard WCSession.default.isReachable else {
            print("Watch: iPhone is not reachable for sync request.")
            return
        }
        let message = ["command": "sync"]
        WCSession.default.sendMessage(message, replyHandler: nil) { error in
            print("Watch error sending sync command: \(error.localizedDescription)")
        }
    }

    // MARK: - WCSessionDelegate

    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        DispatchQueue.main.async {
            if activationState == .activated {
                print("Watch WCSession activated.")
            } else {
                print("Watch WCSession activation failed with error: \(error?.localizedDescription ?? "Unknown error")")
            }
        }
    }

    func session(_ session: WCSession, didReceiveMessage message: [String : Any]) {
        DispatchQueue.main.async {
            print("Watch: Received message from iPhone.")
            if let appDataData = message["appData"] as? Data {
                print("Watch: appData received, size: \(appDataData.count) bytes.")
                do {
                    let decoder = JSONDecoder()
                    let appData = try decoder.decode(AppData.self, from: appDataData)
                    self.loops = appData.loops
                    self.setlists = appData.setlists
                    self.bands = appData.bands
                    print("Watch: Successfully decoded app data. Loops: \(self.loops.count), Setlists: \(self.setlists.count), Bands: \(self.bands.count).")
                } catch {
                    print("Watch error decoding received app data: \(error.localizedDescription)")
                }
            } else {
                print("Watch: appData not found in message.")
            }

            if let playingIDString = message["playingLoopID"] as? String {
                if playingIDString.isEmpty {
                    self.playingLoopID = nil
                } else {
                    self.playingLoopID = UUID(uuidString: playingIDString)
                }
                print("Watch updated playingLoopID: \(self.playingLoopID?.uuidString ?? "None")")
            }
        }
    }

    // Required stubs
    func session(_ session: WCSession, didReceiveApplicationContext applicationContext: [String : Any]) {}
    
}
