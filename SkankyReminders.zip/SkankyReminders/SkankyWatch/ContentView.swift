import SwiftUI

struct ContentView: View {
    @EnvironmentObject var watchSessionManager: WatchSessionManager
    @State private var selectedSetlistID: UUID? = nil

    var filteredLoops: [Loop] {
        if let selectedSetlistID = selectedSetlistID,
           let setlist = watchSessionManager.setlists.first(where: { $0.id == selectedSetlistID }) {
            return setlist.loopIds.compactMap { loopID in
                watchSessionManager.loops.first { $0.id == loopID }
            }
        } else {
            return watchSessionManager.loops.sorted { $0.title.lowercased() < $1.title.lowercased() }
        }
    }

    var body: some View {
        VStack {
            if watchSessionManager.setlists.isEmpty {
                Text("No setlists found. Please sync with your iPhone.")
                    .multilineTextAlignment(.center)
                    .padding()
            } else {
                Picker("Filter", selection: $selectedSetlistID) {
                    Text("All Loops").tag(nil as UUID?)
                    ForEach(watchSessionManager.setlists) { setlist in
                        Text(setlist.name).tag(setlist.id as UUID?)
                    }
                }
                .pickerStyle(.wheel)
            }

            if filteredLoops.isEmpty {
                Text("No Loops Available")
            } else {
                TabView {
                    ForEach(filteredLoops) { loop in
                        VStack {
                            Text(loop.title)
                                .font(.headline)
                                .multilineTextAlignment(.center)
                            Text(loop.band)
                                .font(.subheadline)
                                .foregroundColor(.secondary)

                            HStack {
                                Button(action: { togglePlayback(for: loop) }) {
                                    Image(systemName: watchSessionManager.playingLoopID == loop.id ? "stop.fill" : "play.fill")
                                        .font(.largeTitle)
                                        .foregroundColor(watchSessionManager.playingLoopID == loop.id ? .red : .green)
                                }
                                .buttonStyle(PlainButtonStyle())
                            }
                        }
                    }
                }
                .tabViewStyle(.page)
            }

            Button("Sync Now") {
                watchSessionManager.requestSync()
            }
            .padding()
        }
        .navigationTitle("Skanky Loops")
    }

    private func togglePlayback(for loop: Loop) {
        if watchSessionManager.playingLoopID == loop.id {
            watchSessionManager.stopLoop()
        } else {
            watchSessionManager.playLoop(loopID: loop.id)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        let manager = WatchSessionManager()
        // Populate with sample data for preview
        manager.loops = [
            Loop(id: UUID(), title: "Funky Bassline", band: "Groove Masters", filepath: "", looping: true, setlists: ["SetlistA"], transposeSemitones: 0, tuneCents: 0),
            Loop(id: UUID(), title: "Driving Beat", band: "Rhythm Kings", filepath: "", looping: false, setlists: ["SetlistA"], transposeSemitones: 0, tuneCents: 0)
        ]
        manager.setlists = [
            Setlist(id: UUID(), name: "SetlistA", loopIds: manager.loops.map { $0.id })
        ]
        return ContentView()
            .environmentObject(manager)
    }
}