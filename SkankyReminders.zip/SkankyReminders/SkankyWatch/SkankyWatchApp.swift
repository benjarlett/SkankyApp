import SwiftUI

@main
struct SkankyWatchApp: App {
    @StateObject var watchSessionManager = WatchSessionManager()

    var body: some Scene {
        WindowGroup {
            NavigationView {
                ContentView()
                    .environmentObject(watchSessionManager)
            }
        }
    }
}