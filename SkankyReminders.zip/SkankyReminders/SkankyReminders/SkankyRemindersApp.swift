//
//  SkankyRemindersApp.swift
//  SkankyReminders
//
//  Created by Ben Jarlett on 06/07/2025.
//

import SwiftUI

@main
struct SkankyRemindersApp: App {
    @StateObject var dataManager: DataManager
    @StateObject var audioPlayer: AudioPlayerViewModel
    @StateObject var watchConnectivityManager: WatchConnectivityManager
    
    

    init() {
        // Create instances of the observed objects first
        let dataManagerInstance = DataManager()
        let audioPlayerInstance = AudioPlayerViewModel()
        
        // Initialize the StateObjects with the created instances
        _dataManager = StateObject(wrappedValue: dataManagerInstance)
        _audioPlayer = StateObject(wrappedValue: audioPlayerInstance)
        _watchConnectivityManager = StateObject(wrappedValue: WatchConnectivityManager(audioPlayer: audioPlayerInstance, dataManager: dataManagerInstance))
    }

    var body: some Scene {
        WindowGroup {
            LoopListView()
                .environmentObject(dataManager)
                .environmentObject(audioPlayer)
                .environmentObject(watchConnectivityManager)
                .onReceive(dataManager.$loops) { _ in
                    watchConnectivityManager.sendDataToWatch(loops: dataManager.loops, setlists: dataManager.setlists, bands: dataManager.bands)
                }
                .onReceive(dataManager.$setlists) { _ in
                    watchConnectivityManager.sendDataToWatch(loops: dataManager.loops, setlists: dataManager.setlists, bands: dataManager.bands)
                }
                .onReceive(dataManager.$bands) { _ in
                    watchConnectivityManager.sendDataToWatch(loops: dataManager.loops, setlists: dataManager.setlists, bands: dataManager.bands)
                }
                
        }
    }
}




