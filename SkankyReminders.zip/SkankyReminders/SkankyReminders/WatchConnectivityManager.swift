
import Foundation
import WatchConnectivity

class WatchConnectivityManager: NSObject, ObservableObject, WCSessionDelegate {
    @Published var isReachable: Bool = false
    private var audioPlayer: AudioPlayerViewModel
    private var dataManager: DataManager // Add DataManager dependency

    init(audioPlayer: AudioPlayerViewModel, dataManager: DataManager) {
        self.audioPlayer = audioPlayer
        self.dataManager = dataManager // Initialize DataManager
        super.init()
        if WCSession.isSupported() {
            let session = WCSession.default
            session.delegate = self
            session.activate()
        }
    }

    // MARK: - WCSessionDelegate

    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        DispatchQueue.main.async {
            if activationState == .activated {
                print("WCSession activated.")
                self.isReachable = session.isReachable
                // Send initial data to Watch after activation
                self.sendDataToWatch(loops: self.dataManager.loops, setlists: self.dataManager.setlists, bands: self.dataManager.bands)
            } else {
                print("WCSession activation failed with error: \(error?.localizedDescription ?? "Unknown error")")
            }
        }
    }

    func sessionDidBecomeInactive(_ session: WCSession) {
        print("WCSession did become inactive.")
        self.isReachable = false
    }

    func sessionDidDeactivate(_ session: WCSession) {
        print("WCSession did deactivate. Reactivating...")
        self.isReachable = false
        WCSession.default.activate()
    }

    func sessionReachabilityDidChange(_ session: WCSession) {
        DispatchQueue.main.async {
            self.isReachable = session.isReachable
            print("WCSession reachability changed: \(session.isReachable)")
        }
    }

    func session(_ session: WCSession, didReceiveMessage message: [String : Any], replyHandler: @escaping ([String : Any]) -> Void) {
        print("iPhone: Received message from Watch: \(message)")
        if let command = message["command"] as? String {
            if command == "play", let loopIDString = message["loopID"] as? String, let loopID = UUID(uuidString: loopIDString) {
                if let loop = dataManager.loops.first(where: { $0.id == loopID }) {
                    audioPlayer.play(url: loop.fullPath, shouldLoop: loop.looping, transposeSemitones: loop.transposeSemitones, tuneCents: loop.tuneCents, loopID: loop.id)
                    sendPlayingLoopIDToWatch(loopID: loop.id)
                }
            } else if command == "stop" {
                audioPlayer.stop()
                sendPlayingLoopIDToWatch(loopID: nil)
            } else if command == "sync" {
                print("iPhone: Received sync request from Watch. Sending data...")
                sendDataToWatch(loops: dataManager.loops, setlists: dataManager.setlists, bands: dataManager.bands)
            }
        }
        replyHandler([:]) // Acknowledge receipt
    }

    // MARK: - Sending Data

    func sendDataToWatch(loops: [Loop], setlists: [Setlist], bands: [Band]) {
        guard WCSession.default.isReachable else {
            print("Watch is not reachable.")
            return
        }

        let appData = AppData(loops: loops, setlists: setlists, bands: bands)
        do {
            let encoder = JSONEncoder()
            let data = try encoder.encode(appData)
            let message = ["appData": data]
            WCSession.default.sendMessage(message, replyHandler: nil) { error in
                print("Error sending message to Watch: \(error.localizedDescription)")
            }
            print("Data sent to Watch. Size: \(data.count) bytes.")
        } catch {
            print("Error encoding data for Watch: \(error.localizedDescription)")
        }
    }

    func sendPlayingLoopIDToWatch(loopID: UUID?) {
        guard WCSession.default.isReachable else {
            print("Watch is not reachable for playingLoopID update.")
            return
        }
        let message = ["playingLoopID": loopID?.uuidString ?? ""]
        WCSession.default.sendMessage(message, replyHandler: nil) { error in
            print("Error sending playingLoopID to Watch: \(error.localizedDescription)")
        }
    }
}
