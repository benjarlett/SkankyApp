
import SwiftUI

struct SetlistDetailView: View {
    @Binding var setlist: Setlist
    @EnvironmentObject var dataManager: DataManager
    @Environment(\.presentationMode) var presentationMode

    var body: some View {
        Form {
            Section(header: Text("Setlist Details")) {
                TextField("Setlist Name", text: $setlist.name)
            }

            Section(header: Text("Loops in Setlist")) {
                List {
                    ForEach(setlist.loopIds, id: \.self) { loopID in
                        if let loop = dataManager.loops.first(where: { $0.id == loopID }) {
                            Text(loop.title)
                        }
                    }
                    .onDelete(perform: removeLoopsFromSetlist)
                    .onMove(perform: moveLoopsInSetlist)
                }
            }

            Section(header: Text("Add Loops to Setlist")) {
                List {
                    ForEach(dataManager.loops.filter { !setlist.loopIds.contains($0.id) }) { loop in
                        Button(action: { addLoopToSetlist(loop) }) {
                            Text(loop.title)
                        }
                    }
                }
            }
        }
        .navigationTitle("Edit Setlist")
        .toolbar {
            EditButton()
        }
        .onDisappear(perform: dataManager.saveData)
    }

    private func addLoopToSetlist(_ loop: Loop) {
        if let index = dataManager.setlists.firstIndex(where: { $0.id == setlist.id }) {
            dataManager.setlists[index].loopIds.append(loop.id)
            dataManager.saveData()
        }
    }

    private func removeLoopsFromSetlist(at offsets: IndexSet) {
        if let index = dataManager.setlists.firstIndex(where: { $0.id == setlist.id }) {
            dataManager.setlists[index].loopIds.remove(atOffsets: offsets)
            dataManager.saveData()
        }
    }

    private func moveLoopsInSetlist(from source: IndexSet, to destination: Int) {
        if let index = dataManager.setlists.firstIndex(where: { $0.id == setlist.id }) {
            dataManager.setlists[index].loopIds.move(fromOffsets: source, toOffset: destination)
            dataManager.saveData()
        }
    }
}
