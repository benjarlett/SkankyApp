
import SwiftUI

struct LoopDetailView: View {
    let loopID: UUID // Changed to let loopID
    @EnvironmentObject var dataManager: DataManager
    @Environment(\.presentationMode) var presentationMode
    @EnvironmentObject var audioPlayer: AudioPlayerViewModel // Inject AudioPlayerViewModel
    @State private var showingDeleteAlert = false
    @State private var showingWebView = false
    @State private var webViewURL: URL?

    // Computed property to get the loop from DataManager
    private var loop: Binding<Loop?> {
        Binding(get: {
            dataManager.loops.first(where: { $0.id == loopID })
        }, set: { newValue in
            if let newValue = newValue, let index = dataManager.loops.firstIndex(where: { $0.id == newValue.id }) {
                dataManager.loops[index] = newValue
            }
        })
    }

    var body: some View {
        Form {
            if let unwrappedLoop = loop.wrappedValue { // Access wrappedValue
                Section(header: Text("Loop Details")) {
                    TextField("Title", text: Binding(get: { unwrappedLoop.title }, set: { loop.wrappedValue?.title = $0 }))
                    Toggle("Loop Playback", isOn: Binding(get: { unwrappedLoop.looping }, set: { loop.wrappedValue?.looping = $0 }))
                }

                Section(header: Text("Band")) {
                    Picker("Select Band", selection: Binding(get: { unwrappedLoop.band }, set: { newValue in
                        loop.wrappedValue?.band = newValue
                        dataManager.saveData() // Explicitly save when band changes
                    })) {
                        ForEach(dataManager.bands) { band in
                            Text(band.name).tag(band.name)
                        }
                    }
                }

                Section(header: Text("Setlists")) {
                    ForEach(dataManager.setlists) { setlist in
                        Toggle(setlist.name, isOn: Binding(
                            get: { unwrappedLoop.setlists.contains(setlist.name) },
                            set: { isOn in
                                if var currentLoop = loop.wrappedValue { // Access wrappedValue
                                    if isOn {
                                        currentLoop.setlists.append(setlist.name)
                                        if let setlistIndex = dataManager.setlists.firstIndex(where: { $0.id == setlist.id }) {
                                            dataManager.setlists[setlistIndex].loopIds.append(currentLoop.id)
                                        }
                                    } else {
                                        currentLoop.setlists.removeAll(where: { $0 == setlist.name })
                                        if let setlistIndex = dataManager.setlists.firstIndex(where: { $0.id == setlist.id }) {
                                            dataManager.setlists[setlistIndex].loopIds.removeAll(where: { $0 == currentLoop.id })
                                        }
                                    }
                                    loop.wrappedValue = currentLoop // Assign the modified loop back to the binding
                                    dataManager.saveData()
                                }
                            }
                        ))
                    }
                }

                Section(header: Text("External Links")) {
                    TextField("Spotify Link", text: Binding(get: { unwrappedLoop.spotifyLink ?? "" }, set: { loop.wrappedValue?.spotifyLink = $0.isEmpty ? nil : $0 }))
                    if let spotifyURLString = unwrappedLoop.spotifyLink, let spotifyURL = URL(string: spotifyURLString) {
                        Button(action: {
                            showingWebView = true
                            webViewURL = spotifyURL
                        }) {
                            Text("Open Spotify Link")
                        }
                    }

                    TextField("YouTube Link", text: Binding(get: { unwrappedLoop.youtubeLink ?? "" }, set: { loop.wrappedValue?.youtubeLink = $0.isEmpty ? nil : $0 }))
                    if let youtubeURLString = unwrappedLoop.youtubeLink, let youtubeURL = URL(string: youtubeURLString) {
                        Button(action: {
                            showingWebView = true
                            webViewURL = youtubeURL
                        }) {
                            Text("Open YouTube Link")
                        }
                    }
                }

                Section(header: Text("Chords")) {
                    TextEditor(text: Binding(get: { unwrappedLoop.chords }, set: { loop.wrappedValue?.chords = $0 }))
                        .frame(minHeight: 80)
                        .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.gray.opacity(0.2), lineWidth: 1))
                }

                Section(header: Text("Notes")) {
                    TextEditor(text: Binding(get: { unwrappedLoop.notes }, set: { loop.wrappedValue?.notes = $0 }))
                        .frame(minHeight: 100)
                        .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.gray.opacity(0.2), lineWidth: 1))
                }

                Section(header: Text("Pitch Adjustments")) {
                    VStack {
                        Slider(value: Binding(get: { Double(unwrappedLoop.transposeSemitones) }, set: { newValue in
                            loop.wrappedValue?.transposeSemitones = Int(newValue)
                            if audioPlayer.currentLoopID == loop.wrappedValue?.id {
                                audioPlayer.setPitch(transposeSemitones: Int(newValue), tuneCents: unwrappedLoop.tuneCents)
                            }
                        }), in: -12...12, step: 1) {
                            Text("Transpose (Semitones)")
                        }
                        Text("Semitones: \(unwrappedLoop.transposeSemitones)")
                    }
                    VStack {
                        Slider(value: Binding(get: { Double(unwrappedLoop.tuneCents) }, set: { newValue in
                            loop.wrappedValue?.tuneCents = Int(newValue)
                            if audioPlayer.currentLoopID == loop.wrappedValue?.id {
                                audioPlayer.setPitch(transposeSemitones: unwrappedLoop.transposeSemitones, tuneCents: Int(newValue))
                            }
                        }), in: -100...100, step: 1) {
                            Text("Tune (Cents)")
                        }
                        Text("Cents: \(unwrappedLoop.tuneCents)")
                    }
                }
                
                Section {
                    Button(role: .destructive, action: { showingDeleteAlert = true }) {
                        Text("Delete Loop")
                    }
                }
            }
        }
        .navigationTitle(loop.wrappedValue?.title ?? "Edit Loop")
        .onDisappear(perform: dataManager.saveData)
        .onChange(of: loop.wrappedValue?.id) { _, newValue in
            // If the loop becomes nil (deleted) or its ID changes, dismiss the view
            if newValue == nil {
                presentationMode.wrappedValue.dismiss()
            }
        }
        .sheet(isPresented: $showingWebView) {
            if let url = webViewURL {
                WebView(url: url)
            }
        }
        .alert(isPresented: $showingDeleteAlert) {
            Alert(
                title: Text("Delete Loop?"),
                message: Text("Are you sure you want to delete \(loop.wrappedValue?.title ?? "this loop")? This cannot be undone."),
                primaryButton: .destructive(Text("Delete")) {
                    if let loopToDelete = loop.wrappedValue {
                        presentationMode.wrappedValue.dismiss()
                        DispatchQueue.main.async {
                            dataManager.deleteLoop(loopToDelete)
                        }
                    }
                },
                secondaryButton: .cancel()
            )
        }
    }
}
