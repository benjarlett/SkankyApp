import SwiftUI

struct LoopRowView: View {
    @EnvironmentObject var dataManager: DataManager
    @EnvironmentObject var audioPlayer: AudioPlayerViewModel
    
    let loop: Loop // Changed from var to let
    @Binding var playingLoopID: UUID?
    @Binding var expandedLoopID: UUID?
    @Binding var showingWebView: Bool
    @Binding var webViewURL: URL?
    @Binding var navigationPath: NavigationPath

    var body: some View {
        VStack(alignment: .leading) {
            HStack {
                // Area for title, band, and tap to expand/collapse
                VStack(alignment: .leading) {
                    Text(loop.title)
                        .font(.headline)
                    Text(loop.band)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
                .contentShape(Rectangle()) // Make the whole VStack tappable
                .onTapGesture {
                    if expandedLoopID == loop.id {
                        expandedLoopID = nil // Collapse if already expanded
                    } else {
                        expandedLoopID = loop.id // Expand
                    }
                }
                Spacer()

                // Play/Stop Button (always visible)
                Button(action: {
                    togglePlayback(for: loop)
                }) {
                    Image(systemName: playingLoopID == loop.id ? "stop.fill" : "play.fill")
                        .font(.system(size: 45))
                        .foregroundColor(playingLoopID == loop.id ? .appRed : .appGreen)
                }
                .buttonStyle(PlainButtonStyle()) // Prevents the whole row from being a button
            }
            .padding(.vertical, 8)

            if expandedLoopID == loop.id || playingLoopID == loop.id {
                // Expanded content for playing or explicitly expanded loop
                HStack(alignment: .top) { // Use HStack for horizontal split
                    // Left side: Chords and Notes, and Pen Icon if no text
                    VStack(alignment: .leading) {
                        if loop.chords.isEmpty && loop.notes.isEmpty { // Only show pen if no chords or notes
                            Button(action: {
                                navigationPath.append(loop.id) // Programmatic navigation
                            }) {
                                Image("pen")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(width: 24, height: 24)
                                    .foregroundColor(.accentColor)
                            }
                            .buttonStyle(PlainButtonStyle())
                        } else {
                            if !loop.chords.isEmpty {
                                Text(loop.chords)
                                    .font(.body)
                                    .fontWeight(.bold)
                                    .foregroundColor(.primary)
                                    .padding(.top, 4)
                            }
                            if !loop.notes.isEmpty {
                                Text(loop.notes)
                                    .font(.callout)
                                    .padding(.top, 4)
                            }
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading) // Take as much space as possible

                    Spacer() // Pushes the right content to the trailing edge

                    // Right side: External Links
                    VStack(alignment: .trailing) {
                        Spacer() // Pushes content to the top
                        if let spotifyURLString = loop.spotifyLink, let spotifyURL = URL(string: spotifyURLString) {
                            Button(action: {
                                showingWebView = true
                                webViewURL = spotifyURL
                            }) {
                                Image("spotify")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(width: 45, height: 45)
                            }
                            .buttonStyle(PlainButtonStyle())
                        }
                        if let youtubeURLString = loop.youtubeLink, let youtubeURL = URL(string: youtubeURLString) {
                            Button(action: {
                                showingWebView = true
                                webViewURL = youtubeURL
                            }) {
                                Image("youtube")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(width: 45, height: 45)
                            }
                            .buttonStyle(PlainButtonStyle())
                        }
                    }
                    .padding(.leading, 8) // Add some spacing between left and right content
                }
                .padding(.leading)
                .padding(.bottom, 8)
            }
        }
    }

    private func togglePlayback(for loop: Loop) {
        if playingLoopID == loop.id {
            // Stop the currently playing loop
            audioPlayer.stop()
            playingLoopID = nil
        } else {
            // Stop any previous loop
            audioPlayer.stop()
            
            // Start the new loop
            let url = loop.fullPath
            audioPlayer.play(url: url, shouldLoop: loop.looping, transposeSemitones: loop.transposeSemitones, tuneCents: loop.tuneCents, loopID: loop.id)
            playingLoopID = loop.id
        }
    }
}