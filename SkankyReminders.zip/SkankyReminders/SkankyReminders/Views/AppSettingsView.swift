import SwiftUI

struct AppSettingsView: View {
    @EnvironmentObject var dataManager: DataManager
    @State private var showingAddBandAlert = false
    @State private var newBandName = ""
    @State private var showingAddSetlistAlert = false
    @State private var newSetlistName = ""
    @State private var isPreparingExport = false // New state for background task
    @State private var exportURLs: [URL]?

    var body: some View {
        Form {
            Section(header: Text("File Management")) {
                Button(action: {
                    dataManager.syncFiles()
                }) {
                    Text("Refresh Audio Files")
                }
            }

            Section(header: Text("Data Management")) {
                Button(action: {
                    if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
                       let rootVC = windowScene.windows.first?.rootViewController?.topMostViewController {
                        CSVDocumentPicker.present(
                            presentingViewController: rootVC,
                            onDocumentsPicked: { urls in
                                dataManager.processImportedCSVs(urls: urls)
                            },
                            onCancelled: { /* Handle cancellation if needed */ }
                        )
                    }
                }) {
                    Text("Import Data from CSV")
                }
                Button(action: {
                    isPreparingExport = true // Trigger the background task
                }) {
                    if isPreparingExport {
                        HStack {
                            Text("Exporting...")
                            ProgressView()
                        }
                    } else {
                        Text("Export Data to CSV")
                    }
                }
                .disabled(isPreparingExport)
                if let message = dataManager.importMessage {
                    Text(message)
                        .font(.caption)
                        .foregroundColor(.red)
                        .padding(.top, 5)
                }
            }

            Section(header: Text("Band Management")) {
                List {
                    ForEach($dataManager.bands.filter { $0.wrappedValue.name != "Unknown" }) { $band in
                        TextField("Band Name", text: $band.name)
                            .onChange(of: band.name) { _, _ in
                                dataManager.saveData()
                            }
                    }
                    .onDelete(perform: dataManager.deleteBand)
                }
                Button("Add New Band") {
                    newBandName = ""
                    showingAddBandAlert = true
                }
            }

            Section(header: Text("Setlist Management")) {
                List {
                    ForEach($dataManager.setlists) { $setlist in
                        NavigationLink(destination: SetlistDetailView(setlist: $setlist)) {
                            Text(setlist.name)
                        }
                    }
                    .onDelete(perform: dataManager.deleteSetlist)
                    .onMove(perform: dataManager.moveSetlist)
                }
                Button("Add New Setlist") {
                    newSetlistName = ""
                    showingAddSetlistAlert = true
                }
            }
        }
        .navigationTitle("Settings")
        .toolbar {
            EditButton()
        }
        .task(id: isPreparingExport) { // Runs when isPreparingExport changes
            if isPreparingExport {
                exportURLs = await dataManager.exportDataToCSV()
                if let urls = exportURLs {
                    if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
                       let rootVC = windowScene.windows.first?.rootViewController?.topMostViewController {
                        ExportDocumentPicker.present(presentingViewController: rootVC, urls: urls)
                    }
                }
                isPreparingExport = false // Reset the state
            }
        }
        .alert("Add New Band", isPresented: $showingAddBandAlert) {
            TextField("Band Name", text: $newBandName)
            Button("Add", action: {
                if !newBandName.isEmpty {
                    dataManager.addBand(name: newBandName)
                }
            })
            Button("Cancel", role: .cancel) { }
        }
        .alert("Add New Setlist", isPresented: $showingAddSetlistAlert) {
            TextField("Setlist Name", text: $newSetlistName)
            Button("Add", action: {
                if !newSetlistName.isEmpty {
                    dataManager.addSetlist(name: newSetlistName)
                }
            })
            Button("Cancel", role: .cancel) { }
        }
        
    }
}
