import SwiftUI
import UniformTypeIdentifiers

// MARK: - DocumentPicker (for audio files - existing functionality)
struct DocumentPicker: UIViewControllerRepresentable {
    @EnvironmentObject var dataManager: DataManager
    @Binding var isPresented: Bool

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: [UTType.audio], asCopy: true)
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    class Coordinator: NSObject, UIDocumentPickerDelegate {
        var parent: DocumentPicker

        init(_ parent: DocumentPicker) {
            self.parent = parent
        }

        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            for url in urls {
                _ = url.startAccessingSecurityScopedResource()
                defer { url.stopAccessingSecurityScopedResource() }

                let fileName = url.lastPathComponent
                let newURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent(fileName)

                if !FileManager.default.fileExists(atPath: newURL.path) {
                    do {
                        try FileManager.default.copyItem(at: url, to: newURL)
                        let newLoop = Loop(
                        title: fileName,
                        band: "Unknown",
                        filepath: fileName, // Store only the filename
                        looping: false,
                        setlists: [],
                        transposeSemitones: 0,
                        tuneCents: 0
                    )
                        parent.dataManager.loops.append(newLoop)
                        parent.dataManager.saveData()
                    } catch {
                        print("Error copying file: \(error)")
                    }
                } else {
                    print("File \(fileName) already exists.")
                }
            }
            parent.isPresented = false
        }

        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
            parent.isPresented = false
        }
    }
}

// MARK: - DocumentPickerCoordinator (New: Centralized UIKit Presentation)
class DocumentPickerCoordinator: NSObject, UIDocumentPickerDelegate, ObservableObject {
    var onDocumentsPicked: (([URL]) -> Void)?
    var onCancelled: (() -> Void)?
    var urlsToExport: [URL]?
    var contentTypes: [UTType]?

    // Singleton-like access
    static let shared = DocumentPickerCoordinator()

    private override init() {
        super.init()
    }

    func presentPicker(presentingViewController: UIViewController, urlsToExport: [URL]? = nil, contentTypes: [UTType]? = nil, onDocumentsPicked: (([URL]) -> Void)? = nil, onCancelled: (() -> Void)? = nil) {
        self.urlsToExport = urlsToExport
        self.contentTypes = contentTypes
        self.onDocumentsPicked = onDocumentsPicked
        self.onCancelled = onCancelled

        // Ensure we are on the main thread for UI operations
        DispatchQueue.main.async {
            // Dismiss any active keyboard before presenting the picker
            UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)

            let picker: UIDocumentPickerViewController
            if let urls = self.urlsToExport {
                picker = UIDocumentPickerViewController(forExporting: urls, asCopy: true)
            } else if let types = self.contentTypes {
                picker = UIDocumentPickerViewController(forOpeningContentTypes: types, asCopy: true)
                picker.allowsMultipleSelection = true
            } else {
                fatalError("DocumentPickerCoordinator must be called with urlsToExport or contentTypes.")
            }
            picker.delegate = self

            // Present the picker from the provided presentingViewController
            presentingViewController.present(picker, animated: true, completion: nil)
        }
    }

    // MARK: - UIDocumentPickerDelegate

    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        onDocumentsPicked?(urls)
        controller.dismiss(animated: true, completion: nil)
        cleanupAndDismiss()
    }

    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        onCancelled?()
        controller.dismiss(animated: true, completion: nil)
        cleanupAndDismiss()
    }

    private func cleanupAndDismiss() {
        // Clean up temporary files if this was an export operation
        if let exportURLs = urlsToExport {
            for url in exportURLs {
                do {
                    try FileManager.default.removeItem(at: url)
                    print("Successfully cleaned up temporary export file: \(url.lastPathComponent)")
                } catch {
                    print("Error cleaning up temporary export file \(url.lastPathComponent): \(error.localizedDescription)")
                }
            }
        }
        
        // Reset properties
        urlsToExport = nil
        contentTypes = nil
        onDocumentsPicked = nil
        onCancelled = nil
    }
}

// MARK: - CSVDocumentPicker (now uses DocumentPickerCoordinator)
struct CSVDocumentPicker {
    static func present(presentingViewController: UIViewController, onDocumentsPicked: @escaping ([URL]) -> Void, onCancelled: (() -> Void)?) {
        DocumentPickerCoordinator.shared.presentPicker(
            presentingViewController: presentingViewController,
            contentTypes: [UTType.commaSeparatedText],
            onDocumentsPicked: onDocumentsPicked,
            onCancelled: onCancelled
        )
    }
}

// MARK: - ExportDocumentPicker (now uses DocumentPickerCoordinator)
struct ExportDocumentPicker {
    static func present(presentingViewController: UIViewController, urls: [URL]) {
        DocumentPickerCoordinator.shared.presentPicker(
            presentingViewController: presentingViewController,
            urlsToExport: urls,
            onCancelled: { /* Cleanup handled by coordinator */ }
        )
    }
}

// MARK: - UIViewController Extension (no longer directly used for picker presentation)
extension UIViewController {
    var topMostViewController: UIViewController {
        if let presented = self.presentedViewController {
            return presented.topMostViewController
        }
        if let navigation = self as? UINavigationController {
            return navigation.visibleViewController?.topMostViewController ?? self
        }
        if let tab = self as? UITabBarController {
            return tab.selectedViewController?.topMostViewController ?? self
        }
        return self
    }
}
