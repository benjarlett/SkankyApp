
import SwiftUI

struct LoopListView: View {
    @EnvironmentObject var dataManager: DataManager
    @StateObject private var audioPlayer = AudioPlayerViewModel()
    @State private var selectedSetlistID: String? = "all"
    @State private var showingDocumentPicker = false
    @State private var showingSettings = false
    @State private var playingLoopID: UUID?
    @State private var expandedLoopID: UUID? // New state for expanded notes/chords

    // State for WebView presentation (moved from LoopDetailView)
    @State private var showingWebView = false
    @State private var webViewURL: URL?

    // New state for programmatic navigation to LoopDetailView
    @State private var navigationPath = NavigationPath()

    var filteredLoops: [Loop] {
        if let selectedSetlistID = selectedSetlistID {
            if selectedSetlistID == "all" {
                return dataManager.loops.sorted { $0.title.lowercased() < $1.title.lowercased() }
            } else if let setlist = dataManager.setlists.first(where: { $0.id.uuidString == selectedSetlistID }) {
                // Return loops in the order specified by setlist.loopIds
                return setlist.loopIds.compactMap { loopID in
                    dataManager.loops.first(where: { $0.id == loopID })
                }
            }
        }
        return dataManager.loops.sorted { $0.title.lowercased() < $1.title.lowercased() }
    }

    var body: some View {
        NavigationStack(path: $navigationPath) {
            List(filteredLoops) { loop in
                LoopRowView(
                    loop: loop, // Pass Loop directly
                    playingLoopID: $playingLoopID,
                    expandedLoopID: $expandedLoopID,
                    showingWebView: $showingWebView,
                    webViewURL: $webViewURL,
                    navigationPath: $navigationPath
                )
            }
            .navigationTitle(selectedSetlistID == "all" ? "All Loops" : dataManager.setlists.first(where: { $0.id.uuidString == selectedSetlistID })?.name ?? "All Loops")
            .toolbar {
                ToolbarItem(placement: .principal) {
                    Picker("Filter", selection: $selectedSetlistID) {
                        Text("All Loops").tag("all")
                        ForEach(dataManager.setlists) { setlist in
                            Text(setlist.name).tag(setlist.id.uuidString)
                        }
                    }
                    .pickerStyle(.menu)
                }
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(action: { showingSettings = true }) {
                        Image(systemName: "gear")
                    }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: { showingDocumentPicker = true }) {
                        Image(systemName: "plus")
                    }
                }
            }
            .sheet(isPresented: $showingDocumentPicker) {
                DocumentPicker(isPresented: $showingDocumentPicker)
            }
            .sheet(isPresented: $showingSettings) {
                NavigationView {
                    AppSettingsView()
                }
            }
            // WebView sheet moved here from LoopDetailView
            .sheet(isPresented: $showingWebView) {
                if let url = webViewURL {
                    WebView(url: url)
                }
            }
            // New navigation destination for LoopDetailView
            .navigationDestination(for: UUID.self) { loopID in
                LoopDetailView(loopID: loopID) // Pass loopID directly
            }
        }
    }

    private func togglePlayback(for loop: Loop) {
        if playingLoopID == loop.id {
            // Stop the currently playing loop
            audioPlayer.stop()
            playingLoopID = nil
        } else {
            // Stop any previous loop
            audioPlayer.stop()
            
            // Start the new loop
            let url = loop.fullPath
            audioPlayer.play(url: url, shouldLoop: loop.looping, transposeSemitones: loop.transposeSemitones, tuneCents: loop.tuneCents, loopID: loop.id)
            playingLoopID = loop.id
        }
    }
}
