
import SwiftUI

extension Color {
    static let appBlack = Color(red: 0/255, green: 0/255, blue: 0/255)
    static let appYellow = Color(red: 247/255, green: 236/255, blue: 15/255)
    static let appRed = Color(red: 237/255, green: 33/255, blue: 36/255)
    static let appGreen = Color(red: 104/255, green: 189/255, blue: 69/255)
}
