import Foundation
import UniformTypeIdentifiers // For UTType
import SwiftUI // For UIDocumentPickerViewController

class DataManager: ObservableObject {
    @Published var loops: [Loop] = []
    @Published var setlists: [Setlist] = []
    @Published var bands: [Band] = []
    @Published var importMessage: String? // New property for import messages

    private var dataURL: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("data.json")
    }

    init() {
        loadData()
    }

    func loadData() {
        guard FileManager.default.fileExists(atPath: dataURL.path) else {
            print("Data file does not exist at: \(dataURL.path)")
            ensureUnknownBandExists() // Ensure "Unknown" band exists even if no data file
            importDefaultDataIfNeeded() // Attempt to import default data
            return
        }

        do {
            let data = try Data(contentsOf: dataURL)
            let decoder = JSONDecoder()
            let appData = try decoder.decode(AppData.self, from: data)
            self.loops = appData.loops
            self.setlists = appData.setlists
            self.bands = appData.bands.sorted { $0.name.lowercased() < $1.name.lowercased() }
            ensureUnknownBandExists() // Ensure "Unknown" band exists after loading
            print("Data loaded successfully. Loops: \(loops.count), Setlists: \(setlists.count), Bands: \(bands.count)")
        } catch {
            print("Error loading data: \(error.localizedDescription)")
            ensureUnknownBandExists() // Ensure "Unknown" band exists even if loading fails
            importDefaultDataIfNeeded() // Attempt to import default data if loading fails
        }
    }

    private func importDefaultDataIfNeeded() {
        let defaultsImportedKey = "hasImportedDefaultData"
        if UserDefaults.standard.bool(forKey: defaultsImportedKey) {
            print("Default data already imported. Skipping.")
            return
        }

        print("Attempting to import default data...")
        let bundle = Bundle.main
        let defaultLoopsURL = bundle.url(forResource: "loops", withExtension: "csv", subdirectory: "DefaultData")
        let defaultBandsURL = bundle.url(forResource: "bands", withExtension: "csv", subdirectory: "DefaultData")
        let defaultSetlistsURL = bundle.url(forResource: "setlists", withExtension: "csv", subdirectory: "DefaultData")
        let defaultAudioURL = bundle.url(forResource: "default_loop", withExtension: "mp3", subdirectory: "DefaultData")

        guard let loopsURL = defaultLoopsURL,
              let bandsURL = defaultBandsURL,
              let setlistsURL = defaultSetlistsURL else {
            print("Default CSV files not found in bundle. Skipping default data import.")
            return
        }

        // Copy default audio file if it exists
        if let audioURL = defaultAudioURL {
            let fileName = audioURL.lastPathComponent
            let destinationURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent(fileName)
            if !FileManager.default.fileExists(atPath: destinationURL.path) {
                do {
                    try FileManager.default.copyItem(at: audioURL, to: destinationURL)
                    print("Copied default audio file: \(fileName)")
                } catch {
                    print("Error copying default audio file \(fileName): \(error.localizedDescription)")
                }
            }
        }

        // Process the default CSVs
        processImportedCSVs(urls: [loopsURL, bandsURL, setlistsURL])
        UserDefaults.standard.set(true, forKey: defaultsImportedKey)
        print("Default data import attempt completed.")
    }

    func saveData() {
        let appData = AppData(loops: loops, setlists: setlists, bands: bands)
        do {
            let encoder = JSONEncoder()
            encoder.outputFormatting = .prettyPrinted // For readability
            let data = try encoder.encode(appData)
            try data.write(to: dataURL, options: .atomicWrite)
            print("Data saved successfully to: \(dataURL.path)")
        } catch {
            print("Error saving data: \(error.localizedDescription)")
        }
    }

    func deleteLoop(_ loop: Loop) {
        // 1. Delete the audio file using its fullPath
        do {
            try FileManager.default.removeItem(at: loop.fullPath)
        } catch {
            print("Error deleting file \(loop.fullPath.path): \(error.localizedDescription)")
        }

        // 2. Remove the loop from the main array
        if let index = loops.firstIndex(where: { $0.id == loop.id }) {
            loops.remove(at: index)
        }

        // 3. Remove the loop from all setlists
        for i in 0..<setlists.count {
            setlists[i].loopIds.removeAll { $0 == loop.id }
        }

        saveData()
    }

    private func ensureUnknownBandExists() {
        if !bands.contains(where: { $0.name == "Unknown" }) {
            bands.append(Band(name: "Unknown"))
            saveData() // Save immediately after adding the unknown band
        }
    }

    func syncFiles() {
        let documentsURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let audioExtensions = ["wav", "mp3", "m4a", "aif", "aiff", "caf"]

        do {
            let directoryContents = try FileManager.default.contentsOfDirectory(at: documentsURL, includingPropertiesForKeys: nil, options: [])
            let audioFilesOnDisk = directoryContents.filter { audioExtensions.contains($0.pathExtension.lowercased()) }
            
            // Create a mapping from filename to current valid fileURL on disk
            var fileURLsOnDiskByFilename: [String: URL] = [:]
            for fileURL in audioFilesOnDisk {
                fileURLsOnDiskByFilename[fileURL.lastPathComponent] = fileURL
            }

            var reconciledLoops: [Loop] = []
            var processedDiskFileNames = Set<String>()

            // 1. Process existing loops, updating their filepaths and filtering out deleted files
            for var loop in loops {
                let fileName = URL(fileURLWithPath: loop.filepath).lastPathComponent // Use stored filename
                if fileURLsOnDiskByFilename[fileName] != nil {
                    // File still exists, update its path to the current sandbox path (just the filename)
                    loop.filepath = fileName // Store only the filename
                    reconciledLoops.append(loop)
                    processedDiskFileNames.insert(fileName)
                }
            }

            // 2. Add new files found on disk that are not yet in our loops array
            for fileURL in audioFilesOnDisk {
                let fileName = fileURL.lastPathComponent
                if !processedDiskFileNames.contains(fileName) {
                    let newLoop = Loop(
                        title: fileURL.deletingPathExtension().lastPathComponent,
                        band: "Unknown",
                        filepath: fileName,
                        looping: false,
                        setlists: [],
                        transposeSemitones: 0,
                        tuneCents: 0,
                        notes: "",
                        chords: ""
                    )
                    reconciledLoops.append(newLoop)
                }
            }

            self.loops = reconciledLoops.sorted { $0.title.lowercased() < $1.title.lowercased() }
            saveData()

        } catch {
            print("Error syncing files: \(error.localizedDescription)")
        }
    }

    func addBand(name: String) {
        let newBand = Band(name: name)
        bands.append(newBand)
        bands.sort { $0.name.lowercased() < $1.name.lowercased() }
        saveData()
    }

    func deleteBand(at offsets: IndexSet) {
        bands.remove(atOffsets: offsets)
        saveData()
    }

    func addSetlist(name: String) {
        let newSetlist = Setlist(name: name, loopIds: [])
        setlists.append(newSetlist)
        saveData()
    }

    func deleteSetlist(at offsets: IndexSet) {
        setlists.remove(atOffsets: offsets)
        saveData()
    }

    func moveSetlist(from source: IndexSet, to destination: Int) {
        setlists.move(fromOffsets: source, toOffset: destination)
        saveData()
    }
}

extension DataManager {

    func exportDataToCSV() async -> [URL]? {
        // Generate CSV content for Loops
        let loopsCSV = generateLoopsCSV()
        // Generate CSV content for Bands
        let bandsCSV = generateBandsCSV()
        // Generate CSV content for Setlists
        let setlistsCSV = generateSetlistsCSV()

        // Prepare files for export
        let filesToExport: [(data: Data, filename: String)] = [
            (data: loopsCSV.data(using: .utf8) ?? Data(), filename: "loops.csv"),
            (data: bandsCSV.data(using: .utf8) ?? Data(), filename: "bands.csv"),
            (data: setlistsCSV.data(using: .utf8) ?? Data(), filename: "setlists.csv")
        ]

        let tempDirectory = FileManager.default.temporaryDirectory
        var tempURLs: [URL] = []

        do {
            for file in filesToExport {
                let tempURL = tempDirectory.appendingPathComponent(file.filename)
                // If file exists, remove it
                if FileManager.default.fileExists(atPath: tempURL.path) {
                    try FileManager.default.removeItem(at: tempURL)
                }
                try file.data.write(to: tempURL)
                tempURLs.append(tempURL)
            }
            return tempURLs
        } catch {
            print("Error preparing files for export: \(error.localizedDescription)")
            return nil
        }
    }

    private func generateLoopsCSV() -> String {
        var csvString = "id,title,band,filepath,looping,spotifyLink,youtubeLink,setlists,transposeSemitones,tuneCents,notes,chords\n"
        for loop in loops {
            let setlistsString = loop.setlists.joined(separator: ";") // Join setlist names with a semicolon
            let escapedTitle = escapeCSVString(loop.title)
            let escapedBand = escapeCSVString(loop.band)
            let escapedFilepath = escapeCSVString(loop.filepath)
            let escapedSpotifyLink = escapeCSVString(loop.spotifyLink ?? "")
            let escapedYoutubeLink = escapeCSVString(loop.youtubeLink ?? "")
            let escapedNotes = escapeCSVString(loop.notes)
            let escapedChords = escapeCSVString(loop.chords)

            csvString += "\(loop.id.uuidString),\(escapedTitle),\(escapedBand),\(escapedFilepath),\(loop.looping),\(escapedSpotifyLink),\(escapedYoutubeLink),\"\(setlistsString)\",\(loop.transposeSemitones),\(loop.tuneCents),\(escapedNotes),\(escapedChords)\n"
        }
        return csvString
    }

    private func generateBandsCSV() -> String {
        var csvString = "name\n"
        for band in bands {
            let escapedName = escapeCSVString(band.name)
            csvString += "\(escapedName)\n"
        }
        return csvString
    }

    private func generateSetlistsCSV() -> String {
        var csvString = "name,loopIds\n"
        for setlist in setlists {
            let loopIdsString = setlist.loopIds.map { $0.uuidString }.joined(separator: ";") // Join loop IDs with a semicolon
            let escapedName = escapeCSVString(setlist.name)
            csvString += "\(escapedName),\"\(loopIdsString)\"\n"
        }
        return csvString
    }

    func processImportedCSVs(urls: [URL]) {
        guard let loopsURL = urls.first(where: { $0.lastPathComponent == "loops.csv" }),
              let bandsURL = urls.first(where: { $0.lastPathComponent == "bands.csv" }),
              let setlistsURL = urls.first(where: { $0.lastPathComponent == "setlists.csv" }) else {
            print("Import failed: Please select all three required files: loops.csv, bands.csv, and setlists.csv.")
            DispatchQueue.main.async {
                self.importMessage = "Import failed: Please select all three required files: loops.csv, bands.csv, and setlists.csv."
            }
            return
        }

        do {
            // Start with a clean slate
            var importedBands: [Band] = []
            var importedLoops: [Loop] = []
            var importedSetlists: [Setlist] = []

            // Parse Bands
            let bandsData = try String(contentsOf: bandsURL, encoding: .utf8)
            importedBands = parseBandsCSV(content: bandsData)

            // Parse Loops
            let loopsData = try String(contentsOf: loopsURL, encoding: .utf8)
            importedLoops = parseLoopsCSV(content: loopsData)

            // Parse Setlists
            let setlistsData = try String(contentsOf: setlistsURL, encoding: .utf8)
            importedSetlists = parseSetlistsCSV(content: setlistsData, allLoops: importedLoops)

            // Replace existing data
            DispatchQueue.main.async {
                self.bands = importedBands
                self.loops = importedLoops
                self.setlists = importedSetlists
                self.ensureUnknownBandExists()
                self.saveData()
                print("Successfully imported and replaced data from CSVs.")
                DispatchQueue.main.async {
                    self.importMessage = "Data imported successfully!"
                }
            }

        } catch {
            print("Error processing imported CSV files: \(error.localizedDescription)")
            DispatchQueue.main.async {
                self.importMessage = "Error processing imported CSV files: \(error.localizedDescription)"
            }
        }
    }

    private func parseBandsCSV(content: String) -> [Band] {
        var bands: [Band] = []
        let rows = content.components(separatedBy: .newlines).filter { !$0.trimmingCharacters(in: .whitespaces).isEmpty }
        guard rows.count > 1 else { return [] }

        for row in rows.dropFirst() {
            let columns = row.csvSplit()
            if !columns.isEmpty && !columns[0].isEmpty {
                bands.append(Band(name: columns[0]))
            }
        }
        return bands
    }

    private func parseLoopsCSV(content: String) -> [Loop] {
        var loops: [Loop] = []
        let rows = content.components(separatedBy: .newlines).filter { !$0.trimmingCharacters(in: .whitespaces).isEmpty }
        guard rows.count > 1 else { return [] }

        for row in rows.dropFirst() {
            let columns = row.csvSplit()
            guard columns.count >= 12 else { continue }

            let idString = columns[0]
            let setlistNames = columns[7].split(separator: ";").map(String.init)

            let loop = Loop(
                id: UUID(uuidString: idString) ?? UUID(),
                title: columns[1],
                band: columns[2],
                filepath: columns[3],
                looping: Bool(columns[4]) ?? false,
                spotifyLink: columns[5].isEmpty ? nil : columns[5],
                youtubeLink: columns[6].isEmpty ? nil : columns[6],
                setlists: setlistNames,
                transposeSemitones: Int(columns[8]) ?? 0,
                tuneCents: Int(columns[9]) ?? 0,
                notes: columns[10],
                chords: columns[11]
            )
            loops.append(loop)
        }
        return loops
    }

    private func parseSetlistsCSV(content: String, allLoops: [Loop]) -> [Setlist] {
        var setlists: [Setlist] = []
        let rows = content.components(separatedBy: .newlines).filter { !$0.trimmingCharacters(in: .whitespaces).isEmpty }
        guard rows.count > 1 else { return [] }

        let loopIdMap = Dictionary(uniqueKeysWithValues: allLoops.map { ($0.id.uuidString, $0.id) })

        for row in rows.dropFirst() {
            let columns = row.csvSplit()
            guard columns.count >= 2 else { continue }

            let name = columns[0]
            let loopIdStrings = columns[1].split(separator: ";").map(String.init)
            let loopIds = loopIdStrings.compactMap { loopIdMap[$0] }

            setlists.append(Setlist(name: name, loopIds: loopIds))
        }
        return setlists
    }

    // Helper function to escape strings for CSV (handle commas, quotes, newlines)
    private func escapeCSVString(_ string: String) -> String {
        var escapedString = string
        // If the string contains a comma, double quote, or newline, enclose it in double quotes
        if escapedString.contains(",") || escapedString.contains("\"") || escapedString.contains("\n") {
            // Escape double quotes by doubling them
            escapedString = escapedString.replacingOccurrences(of: "\"", with: "\"\"")
            escapedString = "\"\(escapedString)\""
        }
        return escapedString
    }
}

// Helper to split CSV rows, handling quoted fields.
extension String {
    func csvSplit(separator: Character = ",") -> [String] {
        var result: [String] = []
        var currentField = ""
        var inQuotes = false
        var i = self.startIndex

        while i < self.endIndex {
            let char = self[i]

            if inQuotes {
                if char == "\"" {
                    let nextIndex = self.index(after: i)
                    if nextIndex < self.endIndex && self[nextIndex] == "\"" {
                        // This is an escaped quote
                        currentField.append("\"")
                        i = self.index(after: i) // Move past the second quote
                    } else {
                        // This is the end of the quoted field
                        inQuotes = false
                    }
                } else {
                    currentField.append(char)
                }
            } else {
                switch char {
                case separator:
                    result.append(currentField)
                    currentField = ""
                case "\"":
                    inQuotes = true
                default:
                    currentField.append(char)
                }
            }
            i = self.index(after: i)
        }
        result.append(currentField)
        return result
    }
}


struct AppData: Codable {
    var loops: [Loop]
    var setlists: [Setlist]
    var bands: [Band]
}