import Foundation
import AVFoundation

class AudioPlayerViewModel: ObservableObject {
    private var audioEngine: AVAudioEngine
    private var playerNode: AVAudioPlayerNode
    private var timePitchNode: AVAudioUnitTimePitch
    private var audioFile: AVAudioFile?
    private var audioBuffer: AVAudioPCMBuffer? // New: to hold the audio data for looping

    @Published var isPlaying: Bool = false
    @Published var currentLoopID: UUID? // To track which loop is playing

    init() {
        audioEngine = AVAudioEngine()
        playerNode = AVAudioPlayerNode()
        timePitchNode = AVAudioUnitTimePitch()

        audioEngine.attach(playerNode)
        audioEngine.attach(timePitchNode)

        audioEngine.connect(playerNode, to: timePitchNode, format: nil)
        audioEngine.connect(timePitchNode, to: audioEngine.mainMixerNode, format: nil)

        // Configure the audio session
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default, options: [])
            try AVAudioSession.sharedInstance().setActive(true)
            print("Audio session activated.")
        } catch {
            print("Failed to set audio session category: \(error.localizedDescription)")
        }
    }

    func play(url: URL, shouldLoop: Bool, transposeSemitones: Int, tuneCents: Int, loopID: UUID) {
        stop() // Stop any currently playing audio

        guard FileManager.default.fileExists(atPath: url.path) else {
            print("Error: Audio file does not exist at path: \(url.path)")
            isPlaying = false
            currentLoopID = nil
            return
        }

        do {
            print("Attempting to play audio from URL: \(url.lastPathComponent)")
            audioFile = try AVAudioFile(forReading: url)
            print("Audio file loaded. Format: \(audioFile!.processingFormat), Length: \(audioFile!.length)")
            
            // Read the audio file into a buffer
            let format = audioFile!.processingFormat
            let frameCount = UInt32(audioFile!.length)
            audioBuffer = AVAudioPCMBuffer(pcmFormat: format, frameCapacity: frameCount)
            try audioFile!.read(into: audioBuffer!)
            print("Audio buffer created and filled. Frame length: \(audioBuffer!.frameLength)")

            // Set initial pitch and tune
            timePitchNode.pitch = Float(transposeSemitones * 100) + Float(tuneCents) // 100 cents per semitone
            timePitchNode.rate = 1.0 // Default rate
            print("Pitch set to: \(timePitchNode.pitch), Rate set to: \(timePitchNode.rate)")

            // Schedule the buffer for playback
            if shouldLoop {
                playerNode.scheduleBuffer(audioBuffer!, at: nil, options: .loops, completionHandler: nil)
                print("Buffer scheduled for looping.")
            } else {
                playerNode.scheduleBuffer(audioBuffer!, at: nil, options: [], completionHandler: nil)
                print("Buffer scheduled for single playback.")
            }

            try audioEngine.start()
            playerNode.play()
            print("AudioEngine started and playerNode playing.")
            isPlaying = true
            currentLoopID = loopID

        } catch {
            print("Error playing audio with AVAudioEngine: \(error.localizedDescription)")
            isPlaying = false
            currentLoopID = nil
        }
    }

    func stop() {
        if audioEngine.isRunning {
            playerNode.stop()
            audioEngine.stop()
            playerNode.reset()
            print("Audio stopped.")
            isPlaying = false
            currentLoopID = nil
        }
    }

    func setPitch(transposeSemitones: Int, tuneCents: Int) {
        timePitchNode.pitch = Float(transposeSemitones * 100) + Float(tuneCents)
    }

    deinit {
        stop()
        audioEngine.detach(playerNode)
        audioEngine.detach(timePitchNode)
    }
}