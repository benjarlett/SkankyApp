import Foundation

struct Setlist: Identifiable, Codable {
    let id: UUID // Use let for ID as it should be immutable
    var name: String
    var loopIds: [UUID]

    init(id: UUID = UUID(), name: String, loopIds: [UUID]) {
        self.id = id
        self.name = name
        self.loopIds = loopIds
    }
}