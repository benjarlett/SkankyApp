
import Foundation

struct Band: Identifiable, Codable {
    var id = UUID()
    var name: String
}
