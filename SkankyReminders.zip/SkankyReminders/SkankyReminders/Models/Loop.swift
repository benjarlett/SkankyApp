
import Foundation

struct Loop: Identifiable, Codable {
    let id: UUID
    var title: String
    var band: String
    var filepath: String // This will now store only the filename
    var looping: Bool
    var spotifyLink: String?
    var youtubeLink: String?
    var setlists: [String]
    var transposeSemitones: Int
    var tuneCents: Int
    var notes: String
    var chords: String // New: Chords field

    // Computed property to get the full path at runtime
    var fullPath: URL {
        let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        return documentsDirectory.appendingPathComponent(filepath)
    }

    init(id: UUID = UUID(), title: String, band: String, filepath: String, looping: Bool, spotifyLink: String? = nil, youtubeLink: String? = nil, setlists: [String], transposeSemitones: Int, tuneCents: Int, notes: String = "", chords: String = "") {
        self.id = id
        self.title = title
        self.band = band
        self.filepath = filepath
        self.looping = looping
        self.spotifyLink = spotifyLink
        self.youtubeLink = youtubeLink
        self.setlists = setlists
        self.transposeSemitones = transposeSemitones
        self.tuneCents = tuneCents
        self.notes = notes
        self.chords = chords
    }
}
